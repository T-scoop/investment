<?php
    
?><?php /**PATH C:\wamp64\www\maxprofit\core\resources\views/user/inc/fetch.blade.php ENDPATH**/ ?>