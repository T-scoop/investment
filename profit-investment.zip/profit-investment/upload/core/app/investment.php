<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class investment extends Model
{
    protected $table="invest";
}
