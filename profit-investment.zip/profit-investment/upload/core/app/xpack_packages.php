<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class xpack_packages extends Model
{
    protected $table="xpack_packages";
}
