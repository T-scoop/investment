<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class ref_set extends Model
{
    protected $table="ref_set";
}
